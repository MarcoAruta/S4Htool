class NFA:
    def __init__(self):
        self.states = set()
        self.alphabet = set()
        self.transitions = {}  # {(state, symbol): set(states)}
        self.start_states = set()
        self.accept_states = set()
        self.state_counter = 0  #To keep track of the total number of states


    def add_state(self, state, is_start=False, is_accept=False):
        self.states.add(state)
        if is_start:
            self.start_states.add(state)
        if is_accept:
            self.accept_states.add(state)

    def add_transition(self, src_state, symbol, dest_state):
        if (src_state, symbol) not in self.transitions:
            self.transitions[(src_state, symbol)] = set()
        self.transitions[(src_state, symbol)].add(dest_state)
        self.alphabet.add(symbol)

    def epsilon_closure(self, states):
        closure = set(states)
        stack = list(states)
        while stack:
            state = stack.pop()
            if (state, '') in self.transitions:
                for next_state in self.transitions[(state, '')]:
                    if next_state not in closure:
                        closure.add(next_state)
                        stack.append(next_state)
        return closure

    def move(self, states, symbol):
        result_states = set()
        for state in states:
            if (state, symbol) in self.transitions:
                result_states |= self.transitions[(state, symbol)]
        return result_states

    def accepts(self, input_str):
        current_states = self.epsilon_closure(self.start_states)
        for symbol in input_str:
            current_states = self.epsilon_closure(self.move(current_states, symbol))
        return not self.accept_states.isdisjoint(current_states)

#Function that initialize the NFA given a regular expression (regex)
    def build_from_regex(self, regex, num_states, transitions):
        # Aggiungi gli stati
        for i in range(num_states):
            self.add_state(i, is_start=(i == 0), is_accept=(i == num_states - 1))

        # Aggiungi le transizioni
        for src, dest in transitions:
            self.add_transition(src, '', dest)  # Usa '' per epsilon

    #Thompson's costruction functions: kleene closure (*), concatenate, union (U, nondet choice)
    def add_kleene_closure(self, nfa):
        # Assuming nfa as a tuple (start_state, accept_state)
        start_state = max(self.states) + 1 if self.states else 0
        accept_state = start_state + 1
        self.add_state(start_state, is_start=True)
        self.add_state(accept_state, is_accept=True)

        # Epsilon transition from new start state to original start state
        self.add_transition(start_state, '', nfa[0])

        # Epsilon transition from original accept state to new accept state
        self.add_transition(nfa[1], '', accept_state)

        # Epsilon transition from original accept state back to original start state
        self.add_transition(nfa[1], '', nfa[0])

        # Epsilon transition from new start state to new accept state (to accept epsilon)
        self.add_transition(start_state, '', accept_state)

        # Update the accept states of the NFA
        if nfa[1] in self.accept_states:
            self.accept_states.remove(nfa[1])
        self.accept_states.add(accept_state)

        # Update the start state of the NFA to the new start state
        self.start_state = start_state

        return (start_state, accept_state)

    def concatenate(self, nfa1, nfa2):
        # Assuming nfa1 and nfa2 as tuples (start_state, accept_state)
        # Connect the accept state of nfa1 to the start state of nfa2 with an epsilon transition
        self.add_transition(nfa1[1], '', nfa2[0])
        # Update the accept states of the NFA
        self.accept_states.remove(nfa1[1])
        return (nfa1[0], nfa2[1])

    def union(self, nfa1, nfa2):
        # Creating new initial and final states
        start_state = max(self.states) + 1 if self.states else 0
        self.add_state(start_state, is_start=True)
        accept_state = start_state + 1
        self.add_state(accept_state, is_accept=True)

        # Adding epsilon transitions from the new initial state to the initial states of nfa1 and nfa2
        self.add_transition(start_state, '', nfa1[0])
        self.add_transition(start_state, '', nfa2[0])

        # Adding epsilon transitions from the acceptance states of nfa1 and nfa2 to the new final state
        # Ensure that nfa1[1] and nfa2[1] are in self.accept_states before attempting to remove them
        if nfa1[1] in self.accept_states:
            self.accept_states.remove(nfa1[1])
        if nfa2[1] in self.accept_states:
            self.accept_states.remove(nfa2[1])
        self.add_transition(nfa1[1], '', accept_state)
        self.add_transition(nfa2[1], '', accept_state)

        # Update the start state and accept states of the resulting NFA
        self.start_state = start_state
        self.accept_states.add(accept_state)

        return (start_state, accept_state)

#Build the NFA from a regex
    def build_nfa_from_regex(self, regex):
        postfix_regex = to_postfix(regex)
        return self.compile_to_nfa(postfix_regex)

#New compiling function for NFAs and implementing Thompson algorithm.
    def compile_to_nfa(self, postfix_regex):
        stack = [] #uses a stack for progressively buiding the final NFA
        for symbol in postfix_regex: #For each symbol in regex (postfix notation), does the corresponding operation and updates the stack
            if symbol == '*': #Kleene Closure
                nfa = stack.pop()
                stack.append(self.add_kleene_closure(nfa))
            elif symbol == '|': #Union (Nondeterministic Choice)
                nfa2 = stack.pop()
                nfa1 = stack.pop()
                stack.append(self.union(nfa1, nfa2))
            elif symbol == '.': #Concatenation
                nfa2 = stack.pop()
                nfa1 = stack.pop()
                stack.append(self.concatenate(nfa1, nfa2))
            else:
                stack.append(self.create_basic_nfa(symbol))
        return stack.pop()

#Creating basic NFA function: For each symbol in the alphabet, it creates a basic NFA that recognizes that symbol.
#So this function creates an NFA having two states: an initial state and an acceptance state, linking a transition between these two based on the current symbol.
    def create_basic_nfa(self, symbol):
        start_state = self.state_counter
        self.add_state(start_state, is_start=True)
        self.state_counter += 1

        accept_state = self.state_counter
        self.add_state(accept_state, is_accept=True)
        self.state_counter += 1

        self.add_transition(start_state, symbol, accept_state)
        return (start_state, accept_state)

#Converting NFA into a DFA function:
    def convert_nfa_to_dfa(nfa):
        # Inizializza il DFA
        dfa_states = {}  # Mappa da insiemi di stati NFA a stati DFA
        dfa_start = frozenset(nfa.epsilon_closure(nfa.start_states)) #frozenset for immutabile type key in dictionary as each state in DFA can match to a set of NFA states
        dfa = NFA()  # Reuse NFA class as it is trivial to adapt the same class for DFA
        dfa.add_state(dfa_start, is_start=True)
        dfa_states[dfa_start] = dfa_start
        unmarked_states = [dfa_start]  # DFA state not elaborated yet

        while unmarked_states:
            current_dfa_state = unmarked_states.pop()
            for symbol in nfa.alphabet:
                if symbol == '':  # Ignora le transizioni epsilon nell'NFA
                    continue
                # Calcola la chiusura epsilon della mossa da current_dfa_state con symbol
                next_nfa_states = set()
                for nfa_state in current_dfa_state:
                    moved = nfa.move(set([nfa_state]), symbol)
                    next_nfa_states |= nfa.epsilon_closure(moved)
                next_dfa_state = frozenset(next_nfa_states)

                if next_dfa_state not in dfa_states:
                    dfa_states[next_dfa_state] = next_dfa_state
                    dfa.add_state(next_dfa_state)
                    unmarked_states.append(next_dfa_state)

                # Aggiungi la transizione nel DFA
                dfa.add_transition(current_dfa_state, symbol, next_dfa_state)

        # Imposta gli stati di accettazione nel DFA
        for dfa_state in dfa_states.values():
            if nfa.accept_states.intersection(dfa_state):
                dfa.accept_states.add(dfa_state)

        return dfa

#This function checks if the current state(s) is an acceptance state in the NFA
    def is_in_accepting_state(self, current_states):
        return not self.accept_states.isdisjoint(current_states)


#Shunting Yard Algorithm for regex
def to_postfix(infix):
    precedence = {'*': 50, '.': 40, '|': 30, ')': 20, '(': 10}
    stack = []
    postfix = ''
    for char in infix:
        if char == '(':
            stack.append(char)
        elif char == ')':
            while stack[-1] != '(':
                postfix += stack.pop()
            stack.pop()  # Rimuove '('
        elif char in precedence:
            while stack and precedence[char] <= precedence[stack[-1]]:
                postfix += stack.pop()
            stack.append(char)
        else:
            postfix += char
    while stack:
        postfix += stack.pop()
    return postfix

class State:
    def __init__(self, label=None, is_accept=False):
        self.label = label
        self.is_accept = is_accept
        self.edges = []

class Fragment:
    def __init__(self, start, accept):
        self.start = start
        self.accept = accept

    def compile_to_nfa(postfix):
        stack = []
        for char in postfix:
            if char == '*':
                frag = stack.pop()
                accept = State(is_accept=True)
                start = State(edges=[(frag.start, '')])
                frag.accept.edges.append((start, ''))
                frag.accept.is_accept = False
                stack.append(Fragment(start, accept))
            elif char == '|':
                frag2 = stack.pop()
                frag1 = stack.pop()
                accept = State(is_accept=True)
                start = State(edges=[(frag1.start, ''), (frag2.start, '')])
                frag1.accept.is_accept = False
                frag2.accept.is_accept = False
                frag1.accept.edges.append((accept, ''))
                frag2.accept.edges.append((accept, ''))
                stack.append(Fragment(start, accept))
            elif char == '.':
                frag2 = stack.pop()
                frag1 = stack.pop()
                frag1.accept.edges.append((frag2.start, ''))
                frag1.accept.is_accept = False
                stack.append(Fragment(frag1.start, frag2.accept))
            else:
                accept = State(is_accept=True)
                start = State(edges=[(accept, char)])
                stack.append(Fragment(start, accept))
        return stack.pop()

def match(nfa, string):
    current_states = set([nfa.start])
    next_states = set()

    for char in string:
        for state in current_states:
            for edge in state.edges:
                if edge[1] == char:
                    next_states.add(edge[0])
        current_states, next_states = next_states, set()

    return any(state.is_accept for state in current_states)

def visualize_nfa(nfa):
    print("NFA States:", nfa.states)
    print("Alphabet:", nfa.alphabet)
    print("Start States:", nfa.start_states)
    print("Accept States:", nfa.accept_states)
    print("Transitions:")
    for (src_state, symbol), dest_states in nfa.transitions.items():
        for dest_state in dest_states:
            print(f"  {src_state} --{symbol}--> {dest_state}")

"""The examle demonstrates creating an NFA that accepts the string "ab" or an empty string through an epsilon transition.
 This simple use case illustrates initializing the NFA, adding states and transitions, and checking for acceptance of input strings.

This implementation serves as a foundational library for handling NFAs, which can be extended with additional functionalities such as model checking and handling strategies with recall, as required for more complex applications."""
# Example usage
if __name__ == "__main__":
    nfa = NFA()
    nfa.build_nfa_from_regex("a.b") #PASSARE IN INPUT L'ESPRESSIONE REGOLARE ESTRATTA DALLA LISTA DELLE ESPRESSIONI REGOLARI ESTRATTE DALLA STRATEGIA CORRENTE CON extract_regex_from_strategy(strategy)
#Più precisamente, tale funzione di estrazione ritorna una lista di regex, quindi ciclando per ogni regex in regexes list, lancio la build per ognuna e verifico le stringhe di test.
    visualize_nfa(nfa)
    # Test dell'NFA con varie stringhe
    test_strings = ["", "a", "aa", "aaa", "b", "ab", "ba"]
    for string in test_strings:
        result = "Accepted" if nfa.accepts(string) else "Rejected"
        print(f"String: '{string}' - {result}")

