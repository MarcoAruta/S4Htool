from util.read_input import *
import random


# returns the index of the given atom, in the array of atomic propositions
def get_atom_index(element):
    array = get_atomic_prop()
    try:
        index = np.where(array == element)[0][0]
        return index
    except IndexError:
        print("Element not found in array.")
        return None


# returns the index, given a state name
def get_index_by_state_name(state):
    state_list = get_states()
    index = np.where(state_list == state)[0][0]
    return index


# returns the state, given an index
def get_state_name_by_index(index):
    states = get_states()
    return states[index]


# converts action_string into a list
def build_list(action_string):
    ris = ''
    if action_string == '*':
        for i in range(0, get_number_of_agents()):
            ris += '*'
        action_string = ris
    action_list = action_string.split(',')
    return action_list


# returns a set of agents given a coalition (e.g. 1,2,3)
def get_agents_from_coalition(coalition):
    agents = coalition.split(",")
    return set(agents)


# sort and remove 0 from agents
def format_agents(agents):
    agents = sorted(agents)
    if 0 in agents:
        agents.remove(0)
    agents = {int(x) - 1 for x in agents}
    return agents


# returns coalition's actions
def get_coalition_action(actions, agents):
    coalition_moves = set()
    result = ''
    agents = format_agents(agents)
    if len(agents) == 0:
        for i in range(0, get_number_of_agents()):
            result += '-'
    else:
        for x in actions:
            for i, letter in enumerate(x):
                if i in agents:
                    result += letter
                else:
                    result += '-'

            coalition_moves.add(result)
    return coalition_moves


# returns all moves except for those of the considered coalition
def get_opponent_moves(actions, agents):
    other_moves = set()
    agents = format_agents(agents)
    for x in actions:
        result = ""
        for i, letter in enumerate(x):
            if i not in agents:
                result += letter
            else:
                result += '-'

        other_moves.add(result)
    return other_moves

def get_label(index):
    return f's{index}'

def create_label_matrix(graph):
    label_matrix = []
    for i, row in enumerate(graph):
        label_row = [get_label(i) if isinstance(elem, str) and elem != '*' else None for elem in row]
        label_matrix.append(label_row)
    return label_matrix

 #Extract regular expressions from a natural strategy BOZZA: QUESTA FUNZIONE ESTRAE LE REGEXES DA UNA STRATEGIA SENZA DISTINGUERLE PER APPARTENENZA AD AGENTE
#def extract_regex_from_strategy(strategy):
 #   regexes = []
  #  for condition_action_pair in strategy['condition_action_pairs']:
   #     condition = condition_action_pair[0]  # La condizione è la prima parte della coppia
    #    regexes.append(condition)
    #return regexes

def extract_regex_from_strategy(strategy):
    regexes_per_agent = {}
    for agent_strategy in strategy:
        agent_regexes = []
        for condition_action_pair in agent_strategy['condition_action_pairs']:
            condition = condition_action_pair[0]  # La condizione è la prima parte della coppia
            agent_regexes.append(condition)
        regexes_per_agent[agent_strategy['agent']] = agent_regexes
    return regexes_per_agent

def extract_actions_from_strategy(strategy):
    # Dictionary to store the actions of each agent
    agents_actions = {}

    # Iterate on each "agent strategy" in a list of strategies (condition_action_pairs availables)
    for index, agent_strategy in enumerate(strategy, start=1):
        # Prepare the key for the current agent (es. 'agent1', 'agent2', ...)
        agent_key = f'agent{index}'

        # Extract condition action pairs for the current agent
        condition_action_pairs = agent_strategy['condition_action_pairs']

        # Extract the actions inside condition action pairs
        actions = [action for _, action in condition_action_pairs]

        # Add extracted actions in the agents actions dictionary
        agents_actions[agent_key] = actions

    return agents_actions

#function that return the agents who are missing inside the game coalition
def get_missing_agents(involved_agents):
    # get the total number of agents in the model
    total_agents = get_number_of_agents()

    # create a set of all possible agents based on total_agents number
    all_agents = set(range(1, total_agents + 1))
    # convert the involved agents list in a set for a more efficent search operation
    involved_agents_set = set(involved_agents)
    # subtract the sets to find the missing agents
    missing_agents = list(all_agents - involved_agents_set)

    return missing_agents

def assign_random_actions(missing_agents_actions):
    random_action_assignment = {}
    for agent, actions in missing_agents_actions.items():
        if actions:  # Ensure the list is not empty
            # Select a random action-state pair for the agent
            random_action = random.choice(actions)
            random_action_assignment[agent] = random_action
    return random_action_assignment

def select_random_state_index(missing_agents_actions):
    # Extract all unique state indexes from the actions of all missing agents
    state_indexes = set()
    for actions in missing_agents_actions.values():
        for _, state_index in actions:
            state_indexes.add(state_index)

    # Convert the set to a list to use random.choice
    state_indexes_list = list(state_indexes)

    # Randomly select one state index
    if state_indexes_list:
        selected_state_index = random.choice(state_indexes_list)
        return selected_state_index
    else:
        return None