from src.strategies import initialize, generate_strategies, generate_guarded_action_pairs
from src.pruning import pruning
import time

def process_data(structure, formula, result):
    # Start timer
    start_time = time.time()
    found_solution = False
    # initializes conditions and actions for involved agents
    k, agent_actions, actions_list, atomic_propositions, CTLformula, agents, model = initialize(structure, formula)
    i = 2
    while not found_solution and i <= k:
        #generate guarded action pairs for each agent
        cartesian_products = generate_guarded_action_pairs(i, agent_actions, actions_list, atomic_propositions)
        # generates the initial strategies
        strategies_generator = generate_strategies(cartesian_products, i, agents, found_solution)
        # check for each strategy if there's a solution via pruning & model checking
        for current_strategy in strategies_generator:  # Iterate over the generator object
            print(f"{current_strategy}")
        i += 1
