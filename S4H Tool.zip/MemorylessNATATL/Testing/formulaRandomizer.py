import itertools
import re
import random

def randomize_agents(agents_number):
    # Create a list of all possible agents
    agents = list(range(1, agents_number + 1))

    # Generate all possible subsets of agents
    subsets = sum([list(itertools.combinations(agents, r)) for r in range(1, len(agents) + 1)], [])

    # Randomly select a subset of agents
    return "{" + ",".join(map(str, random.choice(subsets))) + "}"


def randomize_natatl_formula(formula, agents_number, atomic_propositions):
    # Define the possible temporal operators and atomic propositions
    temporal_operators = ["G", "X", "F"]

    # Randomly change temporal operators
    def random_temporal_operator(match):
        return random.choice(temporal_operators)

    formula = re.sub(r'([GXF])', random_temporal_operator, formula)

    # Randomly change logic operators
    def random_logic_operator(match):
        return random.choice(["&&", "||"])

    formula = re.sub(r'(&&|\|\|)', random_logic_operator, formula)

    # Randomly remove negations
    def random_negation(match):
        return "REMOVE_PARENTHESIS" if random.random() < 0.5 else "!"

    formula = re.sub(r'(!)', random_negation, formula)

    # Randomly change atomic propositions
    def random_atomic_proposition(match):
        return random.choice(atomic_propositions)

    # Use a character class with the atomic propositions from get_atomic_props()
    atomic_propositions_pattern = f"[{''.join(atomic_propositions)}]"
    formula = re.sub(atomic_propositions_pattern, random_atomic_proposition, formula)

    # Randomly change the number of agents in the coalition
    def random_coalition(match):
        return "<" + randomize_agents(agents_number) + "," + " " + match.group(2) + ">"

    formula = re.sub(r'<\{((?:\d+,)*\d+)\},\s*(\d+)>', random_coalition, formula)

    # If the negation was removed, remove the surrounding parentheses
    if "REMOVE_PARENTHESIS" in formula:
        formula = formula.replace("REMOVE_PARENTHESIS", "")
        formula = re.sub(r'\((.*)\)', r'\1', formula)

    return formula

#path = 'C:\\Users\\lmfao\\Desktop\\Tesi\\TESTING\\Exists Globally with n agents\\testing5\\model.txt'
#formula = 'C:\\Users\\lmfao\\Desktop\\Tesi\\TESTING\\Exists Globally with n agents\\testing5\\formula.txt'
#if not os.path.isfile(path) or not os.path.isfile(formula):
#    raise FileNotFoundError(f"No such file or directory: {path}")
#read_file(path)
#with open(formula, 'r') as f:
#    natATL = f.read().strip()
#print(natATL)
#n = get_number_of_agents()
#a = get_atomic_prop()
#randomized_formula = randomize_natatl_formula(natATL, n, a)
#print(randomized_formula)
#with open('C:\\Users\\lmfao\\Desktop\\Tesi\\TESTING\\Exists Globally with n agents\\testing1\\modified_formula.txt', 'w') as f:
#    f.write(str(randomized_formula))

# Example usage
#input_formula = "!(<{1,2,3}, 3>Gh || <{1,2,3}, 3>Gb)"
#randomized_formula = randomize_natatl_formula(input_formula, "C:\\Users\\lmfao\\Desktop\\Tesi\\TESTING\\Exists Globally with n agents\\testing5\\model.txt")
#print(randomized_formula)

#NB: tutti i valori tranne k cambiano in maniera randomica in quanto k è l'unico valore che ho ritenuto utile
#variare "a mano" per tenere sotto controllo i costi computazionali durante l'esecuzione