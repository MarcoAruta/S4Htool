import random
from util.read_input import file_to_string

def modify_model(file_path, agent_actions):

    file_content = file_to_string(file_path)
    lines = file_content.split("\n")
    num_agents = int(lines[lines.index("Number_of_agents") + 1])
    name_states = lines[lines.index("Name_State") + 1].split()
    transition_matrix = [row.split() for row in lines[1:1+len(name_states)]]
    labelling_matrix = [row.split() for row in lines[lines.index("Labelling") + 1:lines.index("Labelling") + 1 + len(name_states)]]

    new_state = f"s{len(name_states)}"
    name_states.append(new_state)

    new_transition_row = []
    for _ in range(len(name_states)):
        if len(new_transition_row) == 0:
            new_transition_row.append("I" * num_agents)
        else:
            action = "".join([random.choice(["I"] + agent_actions[f"agent{i+1}"]) for i in range(num_agents)])
            new_transition_row.append(action)

    transition_matrix.append(new_transition_row)

    for row in transition_matrix[:-1]:
        row.append(random.choice(["0", "".join([random.choice(agent_actions[f"agent{i+1}"]) for i in range(num_agents)])]))

    new_labelling_row = [str(random.randint(0, 1)) for _ in range(len(labelling_matrix[0]))]
    labelling_matrix.append(new_labelling_row)

    modified_file_content = "Transition\n"
    for row in transition_matrix:
        modified_file_content += " ".join(row) + "\n"

    modified_file_content += "Name_State\n" + " ".join(name_states) + "\n"
    modified_file_content += "Initial_State\n" + lines[lines.index("Initial_State") + 1] + "\n"
    modified_file_content += "Atomic_propositions\n" + lines[lines.index("Atomic_propositions") + 1] + "\n"
    modified_file_content += "Labelling\n"

    for row in labelling_matrix:
        modified_file_content += " ".join(row) + "\n"

    modified_file_content += "Number_of_agents\n" + str(num_agents)

    with open('C:\\Users\\lmfao\\Desktop\\Tesi\\TESTING\\Exists Globally with n agents\\testing1\\modified_model.txt', 'w') as f:
        f.write(modified_file_content)

    return 'C:\\Users\\lmfao\\Desktop\\Tesi\\TESTING\\Exists Globally with n agents\\testing1\\modified_model.txt'
#input_file = """Transition
#I A B I
#0 I A A,B
#A,B 0 I A,B
#0 A 0 I
#Unkown_Transition_by
#0 0 0 0 0 0 0 0
#0 0 t1 0 0 0 0 0
#0 0 0 c 0 0 0 0
#0 0 0 0 0 0 0 0
#0 0 0 0 0 t1 0 0
#0 0 0 0 0 0 0 0
#0 0 0 0 0 0 0 0
#0 0 0 0 0 0 0 0
#Name_State
#s0 s1 s2 s3
#Initial_State
#s0
#Atomic_propositions
#a b c d e f g h
#Labelling
#1 0 0 0 0 0 0 1
#0 0 0 0 1 0 0 1
#0 0 1 0 0 0 0 1
#1 0 0 0 0 0 0 1
#Number_of_agents
#1"""

#agent_actions = {'agent1': ['B', 'A']}

#modified_file = modify_model(input_file, agent_actions)
#print(modified_file)

#Add-ons: aggiungi anche la possibilità di scegliere randomicamente se nell'aggiunta di un nuovo elemento in transition matrix
# aggiungi due stringhe separate da una virgola oppure una sola stringa oppure uno 0 (nell'impelmentazione attuale vi è solo
#la possibilità di scegliere randomicamente se l'elemento è una stringa o è 0).