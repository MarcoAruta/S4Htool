from src.strategies import initialize, generate_guarded_action_pairs, create_reg_exp, generate_strategies
from src.pruning import pruning
from util.read_input import get_states, get_number_of_states, read_file, get_number_of_agents
from src.tree import build_tree_from_CGS
from util.ATLparser import do_parsingATL
from src.modelCheckingATL import model_checkingATL
import time
import copy

import time
import os
import copy


def preprocess_and_execute(model, formula, results_file, formulaatl):
    start_time = time.time()
    if not os.path.isfile(model):
        raise FileNotFoundError(f"No such file or directory: {model}")
    with open(formulaatl, 'r') as f:
        atlformula = f.read().strip()
        print(f"atl: {atlformula}")
    read_file(model)
    res_parsing = do_parsingATL(atlformula, get_number_of_agents())
    print(res_parsing)

    result = model_checkingATL(atlformula, model)
    print(result)

    if result['initial_state'] == 'Initial state s0: True':
        print("Initial state s0 è True. Avvio natATLwithRecall...")
        natATLwithRecall(model, formula, results_file)
    else:
        print("Initial state s0 NON è True. Terminazione.")

    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"Elapsed time is {elapsed_time} seconds.")


def natATLwithRecall(model, formula, results_file):
    start_time = time.time()
    found_solution = False

    k, agent_actions, actions_list, atomic_propositions, CTLformula, agents, filename, cgs = initialize(model, formula)
    i = 1
    height = 4

    while not found_solution and i <= k:
        print(f"cgs {cgs}")
        tree = build_tree_from_CGS(cgs, get_states(), height)
        print("Initial Tree built from input model:")
        print(tree)

        reg_exp = create_reg_exp(i, atomic_propositions)
        conditions = list(reg_exp)
        actions = list(actions_list)
        cartesian_products = generate_guarded_action_pairs(conditions, actions)
        print(f"cartesian prods {cartesian_products}")

        strategies_iterator = generate_strategies(cartesian_products, i, agents, found_solution)

        for collective_strategy in strategies_iterator:
            print(f"check this strategy set for agents {collective_strategy}")
            tree_copy = copy.deepcopy(tree)

            if pruning(tree_copy, height, filename, CTLformula, *collective_strategy):
                print(f"Solution found {collective_strategy}")
                with open(results_file, 'w') as f:
                    f.write(f"Solution found: {collective_strategy}")
                found_solution = True
                break

        i += 1

    else:
        if not found_solution:
            print("No Solution found")
            with open(results_file, 'w') as f:
                f.write("No solution found")

    end_time = time.time()
    elapsed_time = end_time - start_time
    print(f"Elapsed time is {elapsed_time} seconds.")
    with open(results_file, 'w') as f:
        f.write(f"time is {elapsed_time}")

