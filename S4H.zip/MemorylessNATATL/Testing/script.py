from src.natATLmodelChecking import process_data
import multiprocessing
import time


def algorithm(path, result, formula):
    process_data(path, formula, result)


if __name__ == "__main__":
    path = 'C:\\Users\\lmfao\\Desktop\\Tesi\\TESTING\\Exists Globally with n agents\\testing5\\model.txt'
    formula = 'C:\\Users\\lmfao\\Desktop\\Tesi\\TESTING\\Exists Globally with n agents\\testing5\\formula.txt'
    result = 'C:\\Users\\lmfao\\Desktop\\Tesi\\TESTING\\Exists Globally with n agents\\testing5\\result.txt'

    start_time = time.time()  # Start time
    timeout = 7200  # Total timeout in seconds

    for i in range(1, 101):  # Loop from 1 to 100
        if time.time() - start_time > timeout:
            print("Total execution time exceeded 1 hour. Terminating...")
            break

        process = multiprocessing.Process(target=algorithm, args=(path, result, formula))
        process.start()
        process.join(timeout=timeout - (time.time() - start_time))  # Adjust timeout for each process

        if process.is_alive():
            print(
                f"The execution for current testing is still going after 7200 seconds...Terminating....Time is up! No solution found!")
            process.terminate()
            process.join()