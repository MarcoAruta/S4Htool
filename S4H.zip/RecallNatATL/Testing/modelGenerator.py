import numpy as np

# Definizione delle variabili globali
graph = []
states = []
atomic_propositions = []
matrix_prop = []
initial_state = ''
number_of_agents = ''
states_counter = 0
atomic_propositions_counter = 0


# Funzione per leggere il file di input
def read_file(filename):
    global graph, states, atomic_propositions, matrix_prop, initial_state, number_of_agents, states_counter, atomic_propositions_counter

    with open(filename, 'r') as f:
        lines = f.readlines()

    # reset: global initializations
    graph = []
    states = []
    atomic_propositions = []
    matrix_prop = []
    initial_state = ''
    number_of_agents = ''
    states_counter = 0
    atomic_propositions_counter = 0

    current_section = None
    transition_content = ''
    unknown_transition_content = ''
    name_state_content = ''
    atomic_propositions_content = ''
    labelling_content = ''
    rows_graph = []
    rows_prop = []

    for line in lines:
        line = line.strip()
        if line == 'Transition':
            current_section = 'Transition'
        elif line == 'Unkown_Transition_by':
            current_section = 'Unknown_Transition_by'
        elif line == 'Name_State':
            current_section = 'Name_State'
        elif line == 'Initial_State':
            current_section = 'Initial_State'
        elif line == 'Atomic_propositions':
            current_section = 'Atomic_propositions'
        elif line == 'Labelling':
            current_section = 'Labelling'
        elif line == 'Number_of_agents':
            current_section = 'Number_of_agents'
        elif current_section == 'Transition':
            transition_content += line + '\n'
            values = line.strip().split()
            rows_graph.append(values)
        elif current_section == 'Unknown_Transition_by':
            unknown_transition_content += line + '\n'
        elif current_section == 'Name_State':
            name_state_content += line + '\n'
            values = line.strip().split()
            states = np.array(values)
            states_counter = len(values)  # Aggiornamento di states_counter con il numero di stati
        elif current_section == 'Initial_State':
            initial_state = line
        elif current_section == 'Atomic_propositions':
            atomic_propositions_content += line + '\n'
            values = line.strip().split()
            atomic_propositions = np.array(values)
            atomic_propositions_counter = len(values)
        elif current_section == 'Labelling':
            labelling_content += line + '\n'
            values = line.strip().split()
            rows_prop.append(values)
        elif current_section == 'Number_of_agents':
            number_of_agents = line

    grafo_prov = np.array(rows_graph)
    for row in grafo_prov:
        new_row = []
        for item in row:
            if item == '0':
                new_row.append(0)
            else:
                new_row.append(str(item))
        graph.append(new_row)

    # row = state, column = atom
    matrix_prop_prov = np.array(rows_prop)
    for row in matrix_prop_prov:
        new_row = []
        for item in row:
            if item == '0':
                new_row.append(0)
            elif item == '1':
                new_row.append(1)
            else:
                new_row.append(str(item))
        matrix_prop.append(new_row)

def get_graph():
    return graph

# It returns the name of the states.
def get_states():
    return states

# returns the name of the atomic propositions
def get_atomic_prop():
    return atomic_propositions

def get_number_of_atomic_prop():
    return int(atomic_propositions_counter)

# It returns a matrix that represents the atom labeling function.
# The rows represent the states, and the columns represent the atoms.
# The matrix indicates the values (between 0 and 1) of the atoms in each state.
def get_matrix_proposition():
    return matrix_prop


# returns the initial state
def get_initial_state():
    return initial_state


# returns the number of agents
def get_number_of_agents():
    return int(number_of_agents)

def get_number_of_states():
    return int(states_counter)

# Funzione per espandere la matrice di transizione
def expand_sparse_matrix(matrix, new_size):
    # La matrice sparsa avrà la diagonale diversa da 0, e la prima riga interamente diversa da 0 per rispettare i vincoli imposti dal parser per l'albero corretto
    original_size = len(matrix)
    if original_size == 0:
        raise ValueError("The original matrix has zero size.")

    diagonal_element = matrix[0][0]  # Elemento presente nella prima posizione della prima riga

    expanded_matrix = []

    for i in range(new_size):
        new_row = []
        for j in range(new_size):
            if (i == j):  # Diagonal elements
                new_row.append(diagonal_element)
            elif i == 0:  # First row
                if j < original_size:
                    original_element = matrix[0][j]
                    new_row.append(original_element)
                else:
                    new_row.append('0')
            else:
                new_row.append('0')

        expanded_matrix.append(new_row)

    return expanded_matrix

def expand_sparse_matrix(matrix, new_size):
    # La matrice sparsa avrà la diagonale diversa da 0, e la prima riga interamente diversa da 0 per rispettare i vincoli imposti dal parser per l'albero corretto
    original_size = len(matrix)
    if original_size == 0:
        raise ValueError("The original matrix has zero size.")

    expanded_matrix = []

    for i in range(new_size):
        new_row = []
        for j in range(new_size):
            if (i == j):  # Diagonal elements
                if i < original_size and j < original_size:
                    original_element = matrix[i][j]
                    new_row.append(original_element)
                else:
                    new_row.append('0')
            elif i == 0:  # First row
                if j < original_size:
                    original_element = matrix[0][j]
                    new_row.append(original_element)
                else:
                    new_row.append('0')
            else:
                new_row.append('0')

        expanded_matrix.append(new_row)

    return expanded_matrix



# Funzione per espandere la matrice di labeling
def expand_labelling_matrix(matrix, new_size):
    original_size = len(matrix)
    if original_size == 0:
        raise ValueError("The original labelling matrix has zero size.")

    expanded_matrix = []

    for i in range(new_size):
        expanded_matrix.append(matrix[i % original_size])

    return expanded_matrix


# Funzione per creare un nuovo modello
def create_new_model(file_path1, output_path):
    # Leggi i modelli
    read_file(file_path1)
    transition_matrix1 = get_graph()
    labelling_matrix1 = get_matrix_proposition()

    #read_file(file_path2)
    #transition_matrix2 = get_graph()
    #labelling_matrix2 = get_matrix_proposition()

    # Controlla che le matrici non siano vuote
    if not transition_matrix1:# or not transition_matrix2:
        raise ValueError("One of the transition matrices is empty.")

    if not labelling_matrix1:# or not labelling_matrix2:
        raise ValueError("One of the labelling matrices is empty.")

    # Espandi le matrici
    new_size = 100
    combined_transition_matrix = transition_matrix1
    expanded_transition_matrix = expand_sparse_matrix(combined_transition_matrix, new_size)
    expanded_labelling_matrix = expand_labelling_matrix(labelling_matrix1, new_size)

    # Scrivi il nuovo modello nel file di output
    with open(output_path, 'w') as file:
        file.write('Transition\n')
        for row in expanded_transition_matrix:
            file.write(' '.join(map(str, row)) + '\n')

        file.write('Unkown_Transition_by\n')
        file.write('0 ' * new_size + '\n')

        file.write('Name_State\n')
        for i in range(new_size):
            file.write(f's{i} ')
        file.write('\n')

        file.write('Initial_State\n')
        file.write('s0\n')

        file.write('Atomic_propositions\n')
        file.write('a b c d e f g h\n')

        file.write('Labelling\n')
        for row in expanded_labelling_matrix:
            file.write(' '.join(map(str, row)) + '\n')

        file.write('Number_of_agents\n')
        file.write('3\n')

file_path1 = 'C:\\Users\\utente\\Desktop\\NatATLTool\\RecallNatATL\\Testing\\exampleModelwith10statesDet.txt'
output_path = 'C:\\Users\\utente\\Desktop\\NatATLTool\\RecallNatATL\\Testing\\exampleModelwith100statesDet.txt'
# Crea un nuovo modello
create_new_model(file_path1, output_path)


