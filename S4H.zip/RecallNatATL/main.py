from src.natATLwithRecall import preprocess_and_execute
import multiprocessing

def algorithm():
    model = 'C:\\Users\\utente\\Desktop\\Lavoro\\NatATL-Tool\\RecallNatATL\\Testing\\exampleModelwith10statesDet.txt'
    result = 'C:\\Users\\utente\\Desktop\\Lavoro\\NatSL\\Testing\\Correttezza\\Exists Eventually with n agents\\Next K=4\\testing2\\Risultato.txt'
    formula = 'C:\\Users\\utente\\Desktop\\NatATL-Tooll\\RecallNatATL\\Testing\\formulaNatATLRobot.txt'
    atlformula = 'C:\\Users\\utente\\Desktop\\NatATL-Tooll\\RecallNatATL\\Testing\\formulaATLRobot.txt'
    # main function
    preprocess_and_execute(model, formula, result,atlformula)

if __name__ == "__main__":
    process = multiprocessing.Process(target=algorithm)
    process.start()
    process.join(timeout=7200)  # Set timeout for tests to 7200 seconds (2 hours)

    if process.is_alive():
        print("The execution is still going after 2 hours....Terminating....Time is up! No solution found!")
        process.terminate()
        process.join()



